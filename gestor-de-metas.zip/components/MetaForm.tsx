
import React, { useState, useEffect } from 'react';
import { Meta, Status } from '../types';

interface MetaFormProps {
  selectedMeta: Meta | null;
  onSave: (titulo: string, descricao: string, status: Status) => void;
  onClear: () => void;
  onDeleteRequest: (meta: Meta) => void;
}

const MetaForm: React.FC<MetaFormProps> = ({ selectedMeta, onSave, onClear, onDeleteRequest }) => {
  const [titulo, setTitulo] = useState('');
  const [descricao, setDescricao] = useState('');
  const [status, setStatus] = useState<Status>(Status.Pendente);
  const [error, setError] = useState('');

  useEffect(() => {
    if (selectedMeta) {
      setTitulo(selectedMeta.titulo);
      setDescricao(selectedMeta.descricao);
      setStatus(selectedMeta.status);
      setError('');
    } else {
      setTitulo('');
      setDescricao('');
      setStatus(Status.Pendente);
    }
  }, [selectedMeta]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!titulo.trim()) {
      setError("O campo 'Título' é obrigatório.");
      return;
    }
    setError('');
    onSave(titulo, descricao, status);
  };
  
  const handleNovoClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.preventDefault();
    onClear();
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <h2 className="text-2xl font-bold text-center text-cyan-300">
        {selectedMeta ? 'Editar Meta' : 'Nova Meta'}
      </h2>
      
      <div>
        <label htmlFor="titulo" className="block text-sm font-medium text-gray-300 mb-1">Título</label>
        <input
          id="titulo"
          type="text"
          value={titulo}
          onChange={(e) => setTitulo(e.target.value)}
          placeholder="Ex: Aprender a programar em React"
          className="w-full bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition"
        />
        {error && <p className="text-red-400 text-sm mt-1">{error}</p>}
      </div>

      <div>
        <label htmlFor="descricao" className="block text-sm font-medium text-gray-300 mb-1">Descrição</label>
        <textarea
          id="descricao"
          value={descricao}
          onChange={(e) => setDescricao(e.target.value)}
          rows={5}
          placeholder="Detalhes sobre a meta, passos a serem seguidos, etc."
          className="w-full bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition"
        ></textarea>
      </div>

      {selectedMeta && (
        <div>
          <label htmlFor="status" className="block text-sm font-medium text-gray-300 mb-1">Status</label>
          <select
            id="status"
            value={status}
            onChange={(e) => setStatus(e.target.value as Status)}
            className="w-full bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition"
          >
            {Object.values(Status).map((s) => (
              <option key={s} value={s}>{s}</option>
            ))}
          </select>
        </div>
      )}

      <div className="flex flex-col space-y-3 pt-2">
        <div className="grid grid-cols-2 gap-3">
            <button
                type="button"
                onClick={handleNovoClick}
                className="w-full bg-gray-600 hover:bg-gray-500 text-white font-bold py-2 px-4 rounded-md transition duration-300 ease-in-out"
            >
                Novo
            </button>
            <button
                type="submit"
                className="w-full bg-cyan-600 hover:bg-cyan-500 text-white font-bold py-2 px-4 rounded-md transition duration-300 ease-in-out transform hover:scale-105"
            >
                Salvar
            </button>
        </div>
        {selectedMeta && (
            <button
              type="button"
              onClick={() => onDeleteRequest(selectedMeta)}
              className="w-full bg-red-600 hover:bg-red-500 text-white font-bold py-2 px-4 rounded-md transition duration-300 ease-in-out"
            >
              Excluir Meta
            </button>
        )}
      </div>
    </form>
  );
};

export default MetaForm;
