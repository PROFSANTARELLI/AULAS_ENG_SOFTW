
import React from 'react';
import { Meta, Status } from '../types';

interface MetaItemProps {
  meta: Meta;
  onSelectMeta: (meta: Meta) => void;
}

const statusStyles: { [key in Status]: { color: string; decoration: string; } } = {
  [Status.Concluida]: { color: 'text-green-400', decoration: 'line-through' },
  [Status.EmAndamento]: { color: 'text-yellow-400', decoration: 'no-underline' },
  [Status.Pendente]: { color: 'text-gray-300', decoration: 'no-underline' },
};

const statusBadgeStyles: { [key in Status]: string } = {
    [Status.Concluida]: 'bg-green-500/20 text-green-300 border-green-500/30',
    [Status.EmAndamento]: 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30',
    [Status.Pendente]: 'bg-gray-500/20 text-gray-300 border-gray-500/30',
};


const MetaItem: React.FC<MetaItemProps> = ({ meta, onSelectMeta }) => {
  const { color, decoration } = statusStyles[meta.status];

  const dataFormatada = new Intl.DateTimeFormat('pt-BR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  }).format(new Date(meta.data_criacao));
  
  return (
    <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-lg p-5 transition-all duration-300 hover:border-cyan-500/50 hover:shadow-cyan-500/10 hover:shadow-lg">
        <div className="flex flex-col sm:flex-row justify-between items-start gap-4">
            <div className="flex-1">
                <h4 className={`text-xl font-bold ${color} ${decoration} break-words`}>{meta.titulo}</h4>
                <p className="text-sm text-gray-400 mt-2 break-words">{meta.descricao || "Sem descrição."}</p>
                <div className="flex items-center gap-4 mt-3 text-xs text-gray-500">
                    <span>Criado em: {dataFormatada}</span>
                    <span className={`px-2 py-1 rounded-full text-xs font-semibold border ${statusBadgeStyles[meta.status]}`}>
                        {meta.status}
                    </span>
                </div>
            </div>
            <div className="flex-shrink-0 mt-4 sm:mt-0">
                <button
                    onClick={() => onSelectMeta(meta)}
                    className="bg-gray-700 hover:bg-cyan-700 text-white font-semibold py-2 px-5 rounded-md transition duration-300 ease-in-out text-sm"
                >
                    Editar
                </button>
            </div>
        </div>
    </div>
  );
};

export default MetaItem;
