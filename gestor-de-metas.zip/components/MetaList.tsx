
import React from 'react';
import { Meta } from '../types';
import MetaItem from './MetaItem';

interface MetaListProps {
  metas: Meta[];
  onSelectMeta: (meta: Meta) => void;
}

const MetaList: React.FC<MetaListProps> = ({ metas, onSelectMeta }) => {
  if (metas.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-full bg-gray-800/30 backdrop-blur-sm p-8 rounded-2xl text-center border border-gray-700">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-gray-500 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" />
        </svg>
        <h3 className="text-xl font-semibold text-gray-200">Nenhuma meta cadastrada.</h3>
        <p className="text-gray-400 mt-1">Use o formulário para criar sua primeira meta!</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {metas.map((meta) => (
        <MetaItem key={meta.id} meta={meta} onSelectMeta={onSelectMeta} />
      ))}
    </div>
  );
};

export default MetaList;
