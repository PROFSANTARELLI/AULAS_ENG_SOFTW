
import { Meta, Status } from '../types';

const STORAGE_KEY = 'gestorMetasApp';

export const getAll = (): Meta[] => {
  try {
    const metasJson = localStorage.getItem(STORAGE_KEY);
    if (!metasJson) return [];
    const metas = JSON.parse(metasJson) as Meta[];
    // Ordena as metas para que as mais recentes apareçam primeiro
    return metas.sort((a, b) => new Date(b.data_criacao).getTime() - new Date(a.data_criacao).getTime());
  } catch (error) {
    console.error("Erro ao carregar metas do localStorage:", error);
    return [];
  }
};

export const getById = (id: number): Meta | undefined => {
  const metas = getAll();
  return metas.find(meta => meta.id === id);
};

export const create = (titulo: string, descricao: string): Meta => {
  const metas = getAll();
  const newMeta: Meta = {
    id: Date.now(),
    titulo,
    descricao,
    status: Status.Pendente,
    data_criacao: new Date().toISOString(),
  };
  const updatedMetas = [newMeta, ...metas];
  localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedMetas));
  return newMeta;
};

export const update = (id: number, titulo: string, descricao: string, status: Status): Meta | undefined => {
  let metas = getAll();
  const metaIndex = metas.findIndex(meta => meta.id === id);

  if (metaIndex === -1) {
    console.error(`Meta com ID ${id} não encontrada para atualização.`);
    return undefined;
  }

  const updatedMeta = { ...metas[metaIndex], titulo, descricao, status };
  metas[metaIndex] = updatedMeta;

  localStorage.setItem(STORAGE_KEY, JSON.stringify(metas));
  return updatedMeta;
};

export const deleteById = (id: number): void => {
  let metas = getAll();
  const updatedMetas = metas.filter(meta => meta.id !== id);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedMetas));
};
