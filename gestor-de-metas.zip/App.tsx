
import React, { useState, useEffect, useCallback } from 'react';
import { Meta, Status } from './types';
import * as metaService from './services/metaService';
import MetaForm from './components/MetaForm';
import MetaList from './components/MetaList';
import ConfirmationModal from './components/ConfirmationModal';

function App() {
  const [metas, setMetas] = useState<Meta[]>([]);
  const [selectedMeta, setSelectedMeta] = useState<Meta | null>(null);
  const [metaToDelete, setMetaToDelete] = useState<Meta | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const loadMetas = useCallback(() => {
    const allMetas = metaService.getAll();
    setMetas(allMetas);
  }, []);

  useEffect(() => {
    loadMetas();
  }, [loadMetas]);

  const handleSaveMeta = (titulo: string, descricao: string, status: Status) => {
    if (selectedMeta) {
      metaService.update(selectedMeta.id, titulo, descricao, status);
    } else {
      metaService.create(titulo, descricao);
    }
    setSelectedMeta(null);
    loadMetas();
  };

  const handleSelectMeta = (meta: Meta) => {
    setSelectedMeta(meta);
  };

  const handleClearSelection = () => {
    setSelectedMeta(null);
  };

  const handleDeleteRequest = (meta: Meta) => {
    setMetaToDelete(meta);
    setIsModalOpen(true);
  };

  const handleConfirmDelete = () => {
    if (metaToDelete) {
      metaService.deleteById(metaToDelete.id);
      setIsModalOpen(false);
      setMetaToDelete(null);
      setSelectedMeta(null); // Desseleciona se a meta deletada era a que estava sendo editada
      loadMetas();
    }
  };

  const handleCancelDelete = () => {
    setIsModalOpen(false);
    setMetaToDelete(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-blue-900 text-white font-sans">
      <div className="container mx-auto p-4 sm:p-6 lg:p-8">
        <header className="text-center mb-8">
          <h1 className="text-4xl sm:text-5xl font-extrabold tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-cyan-400">
            🎯 Gestor de Metas Pessoais
          </h1>
          <p className="mt-2 text-lg text-gray-300">Organize seus objetivos e acompanhe seu progresso.</p>
        </header>

        <main className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <aside className="lg:col-span-1">
            <div className="sticky top-8 bg-gray-800/50 backdrop-blur-sm p-6 rounded-2xl shadow-lg border border-gray-700">
              <MetaForm
                selectedMeta={selectedMeta}
                onSave={handleSaveMeta}
                onClear={handleClearSelection}
                onDeleteRequest={handleDeleteRequest}
              />
            </div>
          </aside>

          <section className="lg:col-span-2">
            <MetaList metas={metas} onSelectMeta={handleSelectMeta} />
          </section>
        </main>
      </div>
      
      <ConfirmationModal
        isOpen={isModalOpen}
        onConfirm={handleConfirmDelete}
        onCancel={handleCancelDelete}
        title="Confirmar Exclusão"
        message={`Você tem certeza que deseja excluir a meta "${metaToDelete?.titulo}"? Esta ação não pode ser desfeita.`}
      />
    </div>
  );
}

export default App;
